import{c}from"./createLucideIcon-CRC5s7Oz.js";const e=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],t=c("check",e);export{t as C};
